# Review decisions, sources and acceptance scenarios

## 1. Review decisions

The package is usable for review without answering these immediately. Resolve them before the corresponding implementation or market activation. Proposed defaults are recommendations, not founder approvals.

| ID | Decision | Proposed default / current posture | Needed before |
| --- | --- | --- | --- |
| D01 | Product name | Riparo working name; check ownership/domain/trademark separately | Public branding |
| D02 | Launch order | Mobile-first design; web/PWA first; native apps after core web pilot | Project scheduling |
| D03 | First geography | One staffed Italian area; prior work suggested Rome, not newly confirmed | Provider recruitment/coverage |
| D04 | Europe/USA rollout | Architect for both; activate each approved market in sequence | Market launch |
| D05 | Categories | Seven named trades including Home Appliances + Other/unsure | Catalog and UI |
| D06 | Subscription unit | €9 per provider organization/month, not per worker | Billing schema/terms |
| D07 | Fee amount | Configurable €1–€4; proposed €2 first-customer fee | Billing policy |
| D08 | Fee trigger | First completed qualifying marketplace job | Billing policy |
| D09 | Tax/country pricing | Decide €9 inclusive/exclusive tax; approve USD prices separately | Selling plans |
| D10 | Repair money flow | Marketplace-capable PSP, explicit merchant/counterparty and fee bearer | PSP integration |
| D11 | Voice retention | Editable transcript; temporary audio deleted ≤24h after transcription, unless approved exception | Personal-data processing |
| D12 | Languages | IT/EN/BN tested first; ES prepared; no untested “all languages” guarantee | QA and pilot |
| D13 | Qualification policy | Country/work-type matrix and evidence review, not category badge alone | Dispatch |
| D14 | Matching commercial role | Organic launch; separate disclosed sponsorship only later | Ranking implementation |
| D15 | Core plan limits | Publish fair use; no unlimited AI telephone included by assumption | Pricing/plan screen |
| D16 | Custody scope | Enable pickup/return only when actual transport and liability process is staffed | Mode activation |
| D17 | Cancellation/diagnosis/refunds | Written country-specific fees, consent and settlement rules | Customer booking |
| D18 | Privacy and retention | Per-data-class schedule, vendor processing region/contracts and legal holds | Real user data |
| D19 | Financial documents | Accountant-approved issuer, numbering, tax and e-invoice adapter per market | Invoice issuance |
| D20 | Historical repository reuse | Audit source instead of treating old table counts/version labels as readiness proof | Estimates/schema implementation |

### Resolved priority conflicts

Latest pricing replaces old lead packages, free leads/referrals or per-ticket percentages unless separately reapproved. Retain the eight-category taxonomy rather than losing appliances. Retain PostgreSQL/PostGIS instead of reverting to MySQL. Preserve the artistic line/cream/ink direction from the reviewed PDF and handoff. New speech-to-text rule replaces older voice-note mockups. Shared-language preference is retained; nationality/culture matching and hidden paid ranking are replaced by the proposed suitability and transparency policy, awaiting owner review.

## 2. Market activation checklist

This is a product readiness checklist, not a legal opinion or a universal list of obligations. A named local reviewer must confirm the applicable requirements for the actual work, business model and jurisdiction. Do not paste a generic global policy into the app.

| Area | Italy / European pilot | Selected US market |
| --- | --- | --- |
| Trade scope | Work-type eligibility, required person/business qualifications and checks; F-gas verification where applicable | State/local trade licensing and work-scope verification; selected state/city first |
| Business/counterparty | Provider identity, entity/tax details, contracting relationship and insurance | Entity/provider onboarding, licensing, insurance and independent-contractor/marketplace review |
| Privacy | Applicable privacy notice, processing basis, rights, retention, vendors and cross-border processing review | Applicable state/federal privacy, communications and retention review |
| Consumer terms | Price disclosure, cancellation/withdrawal where applicable, urgent work consent, warranty/complaints | Applicable price/cancellation/repair warranty and consumer protection review |
| Money | PSP country support, onboarding, tax documents, refund/payout responsibilities | PSP/state coverage, fee allocation, tax/reporting and dispute model |
| Invoices | Approved issue/credit/numbering and any required local electronic workflows | Applicable sales tax/invoice/receipt treatment by work and jurisdiction |
| Emergency content | Locally approved scripts and official routes; no false emergency-service promise | Local official routes and appropriate scripts; no automatic reuse of Italian content |
| Calls/location | Approved disclosure, recording policy, active-job location notice | State-sensitive call/recording review and clear tracking notice |

Sources W5–W8 are starting official resources, not evidence that Riparo is already compliant or eligible in a country. Complete specialist review before activating restricted categories or a new jurisdiction.

## 3. Acceptance scenarios

These are test specifications for developers/QA, not claims that tests were executed on an application in this documentation task.

| Test | Given / action | Expected outcome |
| --- | --- | --- |
| T01 | Customer speaks Bangla about an appliance, edits transcription | Corrected original text persists; source revision and language retained |
| T02 | Microphone permission refused | Typing/file selection remain usable; draft preserved |
| T03 | Transcription/model timeout | Clear retry/edit/manual route; no fabricated summary or dispatch |
| T04 | AI detects uncertain brand/model | Customer sees uncertainty and can select unknown; no forced invented identifier |
| T05 | Customer confirms summary, then materially changes category | Confirmed revision invalidated; affected offers close/reconfirm |
| T06 | Hazard phrase/rule triggered in intake or chat | Ordinary booking interrupted; approved local escalation; AI cannot override |
| T07 | Provider lacks required valid scope | Excluded from offer/assignment regardless of proximity or payment plan |
| T08 | Shop qualifies but assigned worker does not | Assignment prevented unless approved supervision policy actually allows it |
| T09 | Ready part-time professional with no ratings | Eligible during declared hours; neutral prior and exploration opportunity |
| T10 | Language preference unavailable | User informed; translated options remain; no ethnicity/nationality filtering |
| T11 | Provider responds available | Customer notified; job not booked automatically; fee not charged |
| T12 | Customer app background/muted | Visible/push state where permitted; no false guaranteed ringing promise |
| T13 | Two booking commands/retries for one request | Exactly one active booking; idempotent result or clear conflict |
| T14 | Two customers select same single-capacity worker/time | Only valid capacity commits; other customer can reselect |
| T15 | Offer expires during booking | Transaction rejects stale response and releases hold safely |
| T16 | Queue restarts after booking commit | Outbox retries notify once effectively; booking remains durable |
| T17 | Technician A opens shop B job/media/socket/export | Access denied without leaking private resource existence |
| T18 | RAG query from shop A | No shop B CRM/manual-job documents retrieved |
| T19 | Chat says €85, model translates numerals incorrectly | Structured quote remains €85; critical mismatch triggers correction, not auto approval |
| T20 | Quote v1 approved; provider submits extra cost in v2 | Extra work blocked pending v2 approval; v1 evidence retained |
| T21 | Customer rejects diagnosis quote | Repair stops; only previously accepted diagnosis/return charges remain eligible |
| T22 | Pickup repair completed but item not returned | Job shows ready/return pending; custody not falsely closed |
| T23 | Wrong/damaged item at handover | Condition/accessory evidence and incident route; no silent acknowledgement |
| T24 | Browser redirects to payment success without valid webhook | Payment stays pending until authoritative verification/reconciliation |
| T25 | Same PSP webhook replayed/out of order | One financial effect; no state regression or duplicate refund |
| T26 | First customer with shop A completes two jobs concurrently | One relationship and at most one acquisition debit |
| T27 | Same customer returns to another A employee/branch | Zero further acquisition fee |
| T28 | Same customer first completes work with independent B | One eligible fee for B; A history unchanged |
| T29 | Walk-in contact/manual shop job completed | No marketplace acquisition debit |
| T30 | Acquisition fee credited/refunded | Append-only credit; relationship persists; no accidental automatic re-charge |
| T31 | Subscription unpaid during active customer repair | Grace/restriction policy applies; records and active support remain reachable |
| T32 | Location stops updating or job ends | Stale marker/last update shown; sharing expires and further unauthorized posts rejected |
| T33 | Schedule crosses DST change | Clear timezone/offset confirmation; intended slot preserved without collision |
| T34 | Customer requests erasure with open legal/accounting retention | Process rights workflow; minimize retained data and explain approved exception |
| T35 | New private upload with forged MIME/oversized media | Reject/quarantine safely; no public exposure or executable content |
| T36 | Provider certificate expires after offer but before booking | Recheck prevents invalid booking/assignment; support notified |
| T37 | Screen-reader/keyboard/large-text customer approves quote | Accessible exact amount/version/action; focus and layout remain usable |
| T38 | Account/organization merge reveals duplicate relationship | Audited canonicalization and adjustment; historical ledger not erased |
| T39 | Database/Redis outage and restore drill | No invented state; recovery follows runbook; measured RPO/RTO recorded |
| T40 | Inbound AI caller mentions emergency or asks for discount/payment | Approved handoff/safety behavior; no unauthorized booking, price promise or charge |

For each implemented requirement, the team records covered test IDs, real command/results, environment and evidence link. Passing synthetic fixtures does not establish operational or legal readiness.

## 4. Project sources reviewed

The latest founder message dated 18 October 2026 is the primary authority for category intent, transcription behavior, provider/customer acceptance and the €9 plus once-per-customer fee model.

Current files read for this package: `IMPLEMENTATION_STATUS.md` (complete), `README(1).md` (complete), `FINAL_DESIGN_AND_DEVELOPMENT_HANDOFF(1).md` (design and core flow sections), `Riparo_Italy_Pilot_Deep_Analysis_and_PRD.docx` (opening analysis/requirements sections), and `Repair App Wireframes(1).pdf` (page 1 text and visual inspection). Prior conversation retrieval supplied additional project decisions. This is a targeted consolidation, not a claim to have read every account conversation, every PDF or the actual production source.

The supplied wireframe's arrival-code wording is ambiguous. This package standardizes customer-held code → technician validates on arrival. Older free-lead/referral offers and example price ranges are not automatically carried into the new commercial policy. Prior status/README files disagree on engine/framework major versions and describe incomplete integrations, so actual repository/runtime audit is mandatory.

## 5. Public references checked on 18 October 2026

These links support candidate selection and review checklists. Recheck version, tariff, licence and country availability at implementation; this document does not freeze a third party's future terms.

- W1 — SYSTRAN faster-whisper official repository: https://github.com/SYSTRAN/faster-whisper
- W2 — Qwen3-8B official model card: https://huggingface.co/Qwen/Qwen3-8B
- W3 — Qwen3-Embedding-0.6B official model card: https://huggingface.co/Qwen/Qwen3-Embedding-0.6B
- W4 — Gemini Developer API official pricing and data-use distinctions: https://ai.google.dev/gemini-api/docs/pricing
- W5 — Stripe Connect documentation, marketplace payment capabilities: https://docs.stripe.com/connect
- W6 — European Commission data protection overview: https://commission.europa.eu/law/law-topic/data-protection/data-protection-explained_en
- W7 — Italian F-gas portal: https://www.fgas.it/
- W8 — US Small Business Administration business launch guidance: https://www.sba.gov/counseling/launch-your-business/

## 6. Approval and next deliverables

Review D02–D10 first because they affect architecture, transactions and pricing. Once the requirements are accepted, produce the physical ERD/data dictionary, SQL/migrations and representative artistic UI screens. After those are reviewed, expand the full screen set and implement the first vertical slice. This ordering follows the founder's request to settle requirements before final database and mobile design.
