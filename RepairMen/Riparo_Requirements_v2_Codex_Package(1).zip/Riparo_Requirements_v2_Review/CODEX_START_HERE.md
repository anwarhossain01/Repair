# Codex starter prompt

Copy the following into the coding session and attach all Markdown files and the actual repository.

> You are implementing Riparo / Repairmen. Read this package in the order in 00_READ_ME_FIRST.md, then read repository AGENTS.md and actual source. The package is a review baseline: latest founder decisions override older demos. First audit existing code, tests, schema and adapters, and produce a requirement-to-code reuse map. Distinguish verified code, demo-only code, missing integrations and untested claims.
>
> Do not implement unapproved policy choices as settled facts. Start from web/PWA first, mobile-first UX, Laravel modular backend, PostgreSQL/PostGIS, Redis and Next.js. Preserve the approved stack and existing working code. After requirements approval, produce a physical schema/migration plan before applying database changes.
>
> Enforce: tenant/participant isolation; one active booking per request; exact-version quote approval; one acquisition fee per canonical customer and provider organization; no repeat fee across shop staff/branches; deterministic eligibility/safety; idempotent webhooks/outbox; private media; voice input converted to editable text before send. AI cannot set binding prices, override permissions or charge payments.
>
> Work one reviewed feature increment at a time. Cite requirement IDs, define API/state/data effects, implement, run meaningful PostgreSQL/integration tests, demonstrate UI states and update traceability. Never claim a mock is production. Do not deploy production, run destructive migrations, send messages or introduce charges without the coding session's explicit scope/authority. Report concrete blockers and continue independent authorized work.

## Suggested first tasks

1. Repository audit, version matrix, source reuse map and missing decisions.
2. Review logical model and generate proposed physical ERD/schema, without destructive execution.
3. After approval, tenant/auth foundation and migration tests.
4. One end-to-end ordinary repair vertical slice, including transcript confirmation, provider choice and quote approval.
5. Concurrency, billing, privacy, failure and real-provider integration gates before production.
