# Riparo — requirements review package v2.0

Prepared for Anwar Hossain · 18 October 2026 · Requirements baseline for review

## What this package is

This is the proposed product contract for the Repairmen / Reparo / Riparo project. Riparo is the working product name throughout. The latest founder brief takes precedence over earlier documents. This package defines the full intended product, a bounded first release, functional behavior, technical delivery, a provisional logical database model, and the design brief.

The next decision is requirements approval. Production SQL, migrations and the final visual screen set follow that review. The logical model here is deliberately detailed enough to expose mistakes before schema implementation. No application has been built or deployed by preparing this package.

## Read in this order

1. `01_MASTER_PRODUCT_REQUIREMENTS.md` — product, journeys, requirements and business rules.
2. `02_TECHNICAL_TEAM_AND_CODEX_PLAN.md` — architecture, delivery steps, API contracts and quality gates.
3. `03_LOGICAL_DATABASE_BLUEPRINT.md` — entities, relationships, integrity and lifecycle rules; provisional.
4. `04_DESIGN_AND_SCREEN_BLUEPRINT.md` — artistic UI direction and web/mobile screen inventory.
5. `05_INVESTOR_AND_PARTNER_BRIEF.md` — opportunity, business model, illustrative economics and proof plan.
6. `06_DECISIONS_SOURCES_AND_ACCEPTANCE.md` — review decisions, evidence, references and acceptance scenarios.
7. `CODEX_START_HERE.md` — copy this prompt into Codex with the package.

The PDF combines these documents for reading. The ZIP contains the editable Markdown originals and a machine-readable requirement register. Give Codex the ZIP contents rather than relying only on PDF extraction.

## Main decisions captured

- Customer marketplace + professional workspace + repair-shop management + platform operations.
- Web/PWA launches first; customer and technician mobile apps reuse the same backend later. Design mobile-first from the start. The brief's phrase “first develop the mobile app” is interpreted as mobile-first UX preparation, because it explicitly states web launches before mobile. Native implementation order remains a review decision.
- Italy is the first operational pilot; Europe and the USA are expansion targets supported in the architecture. Proposed sequence is one Italian service area, then additional approved areas/countries, then a selected US city/state; simultaneous launch requires separately staffed country operations.
- Seven named trade categories, including retained Home Appliances, plus Other / I'm not sure.
- Speaking produces editable text. Voice notes are not the default communication object. Customer confirmation precedes dispatch.
- Technician response does not automatically book a repair. Customer selects one responding provider; a later quote requires separate approval.
- €9 per month per freelancer/provider organization or shop organization; not per employee. One-time €1–€4 acquisition fee for each new marketplace customer–provider organization relationship. Exact fee and tax presentation await review.
- Repeat work with that same organization carries no further customer-acquisition fee, even with another employee or branch. Repair payments and payment-processing costs are separate.
- PostgreSQL/PostGIS, Laravel modular backend, Next.js/TypeScript responsive web, Redis workers and object storage; React Native apps later.
- AI assists intake, transcription, translation and retrieval. Deterministic code controls eligibility, matching constraints, money, permissions, safety escalation and state transitions.

## Review posture

Labels used throughout: **Founder requirement** = latest explicit request; **Retained** = prior decision supported by project records; **Proposed** = recommended default awaiting review; **Deferred** = full-product requirement scheduled after the first release. All targets and commercial scenarios are planning assumptions, not verified traction or guarantees.

Earlier status documents describe demos and source foundations, with real auth, payments, dispatch, background location and integrations still incomplete. Audit the actual repository before estimating reuse. Older files disagree on framework/database major versions; this package retains the stack but requires a tested, supported version matrix at kickoff.
