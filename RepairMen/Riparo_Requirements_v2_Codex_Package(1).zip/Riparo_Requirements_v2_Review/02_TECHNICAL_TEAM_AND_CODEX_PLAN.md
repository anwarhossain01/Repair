# Technical team requirements and Codex delivery plan

Status: proposed implementation specification; review alongside the product requirements.

## 1. Architecture decision

Retain a Laravel modular monolith for transactional business rules, PostgreSQL with PostGIS for durable data and geography, Redis for queues/cache/short-lived coordination, and Next.js/TypeScript for public and authenticated responsive web. Add a small private Python AI worker/service for speech/model processing where useful. Customer and professional native apps use React Native after the web pilot.

This fits the founder's PHP/Laravel experience and avoids distributing the first booking and billing transactions across many services. A module boundary is a code ownership boundary; it does not require a separate server. Do not introduce RabbitMQ, Kubernetes, a second document database or a separate vector service without a demonstrated need.

PostgreSQL is the system of record. Redis loss must not erase confirmed bookings, billing or durable job events. Object storage holds media bytes; PostgreSQL holds authorization, ownership, revisions and metadata. pgvector is optional for approved RAG retrieval after verifying extension and embedding-model compatibility; ordinary relational/full-text retrieval is acceptable initially.

### Proposed module map

| Module | Owns | Key boundaries |
| --- | --- | --- |
| Identity/organizations | Users, memberships, roles, sessions | Trusted actor and workspace resolution |
| Catalog/territories | Categories, work types, geography, policy | Country/category activation |
| Verification | Evidence, reviewer decisions, qualification scope | Eligibility read by dispatch |
| Intake/media/AI | Drafts, transcripts, summaries, temporary files | No booking or money authority |
| Dispatch | Candidate filters, rounds, responses, holds | No final quote authority |
| Jobs/scheduling | Booking, assignment, state, custody | One request → one active booking |
| Communication | Original messages, translations, participant access | Job/organization authorization |
| Quotes/documents | Versions, approval, invoice/receipt snapshots | Explicit customer price approval |
| Repair payments | Intent/capture/refund/payout/reconciliation | PSP-authoritative transitions |
| Platform billing | Subscription, relationships, acquisition ledger | Separate from repair funds |
| Shop operations | CRM, manual jobs, branches, inventory | Tenant isolation |
| Support/trust | Reports, disputes, incidents, warranties | Audited access and outcomes |
| Notifications/audit | Outbox, delivery attempts, append-only events | Retry and deduplication |

### Runtime topology

Browser/native → HTTPS edge → Next.js/web and Laravel API. Laravel communicates with the writer database, Redis and private object storage. Workers consume durable jobs and call approved AI/payment/message adapters. WebSocket/SSE events notify authorized participants; polling recovers state after disconnect. No browser receives provider secret keys or direct database access.

Use one PostgreSQL writer initially. Read replicas may later serve stale-tolerant reports; booking, permissions and money use consistent writer reads. UUIDs avoid ID collision; they do not provide safe multi-writer replication.

## 2. Repository and team ownership

Suggested structure:

```
apps/web/
apps/customer-mobile/       # after web gates
apps/technician-mobile/     # after web gates
services/api/app/Modules/
services/ai/
packages/api-contracts/
packages/design-tokens/
docs/product/
docs/architecture/decisions/
docs/qa/
infrastructure/
```

One product owner approves requirements and price policy. One technical lead owns data integrity and contracts. Backend owns authorization/state/money. Web owns accessible mobile-first flows. AI owns model evaluations, not financial policy. QA/operations jointly own end-to-end acceptance. A reviewer with relevant local expertise owns market-specific trade/safety/legal activation. Small teams may combine roles but must retain named accountability.

Do not assume a prior demo is the production repository. First inspect code, manifests, migrations, tests, live integration adapters and deployment evidence. Produce a reuse matrix: verified reusable, adaptation needed, demo-only, missing. Prior status documents explicitly leave real integrations and operational checks unfinished.

## 3. API and event contract

Version public endpoints under `/api/v1`; describe them in OpenAPI before client implementation. Use authenticated actor resolution and server-side workspace membership. `organization_id` sent by a client is a selector to authorize, never proof of tenancy. All UUID resource lookups check ownership/participants.

| Resource/action | Contract essentials |
| --- | --- |
| `POST /intakes` | Anonymous/verified draft with abuse limits; draft access token |
| `POST /media/upload-intents` | Purpose, MIME/size limits, scoped expiring upload URL |
| `POST /intakes/{id}/transcriptions` | Async job, transcript revision, language, retry state |
| `PATCH /intakes/{id}` | Expected revision; prevent silent overwrite |
| `POST /requests/{id}/confirm` | Confirmed source revision, mode, address/time, policy acceptance |
| `POST /requests/{id}/dispatch` | Allowed only after confirmation and safety/coverage checks |
| `POST /offers/{id}/respond` | Provider organization, qualified capacity, expiry, no duplicate response |
| `POST /responses/{id}/book` | Idempotency key; atomic slot + request booking guards |
| `POST /jobs/{id}/transitions` | Explicit command, expected version, permitted actor, reason |
| `POST /jobs/{id}/quotes` | Itemized draft; immutable submitted version |
| `POST /quotes/{id}/approve` | Customer, exact quote version/hash, amount/currency |
| `POST /jobs/{id}/messages` | Original text/language and attachment permissions |
| `POST /jobs/{id}/locations` | Assigned technician, en-route state, time, accuracy, sequence |
| `POST /jobs/{id}/payment-intents` | Server-computed payable amount; PSP reference |
| `POST /webhooks/{provider}` | Signature verification, durable event receipt, deduplication |
| `GET /workspaces/{id}/reports` | Permission/currency/date scope and pagination |

Mutation responses return resource version, canonical state and timestamps. Use stable machine error codes plus localized explanations: forbidden, stale_revision, offer_expired, no_capacity, quote_not_approved, payment_pending, qualification_expired. Use 409 for state/version conflicts, validation errors for bad inputs, and 202 for accepted asynchronous processing. Sensitive errors must not reveal that another tenant's resource exists.

Events include `RequestConfirmed`, `OfferResponded`, `BookingConfirmed`, `AssignmentChanged`, `QuoteSubmitted`, `QuoteApproved`, `JobCompleted`, `PaymentUpdated`, `CustodyTransferred`, `RelationshipQualified`, `AcquisitionFeeRecorded`. Version event schemas. Commit state and outbox row together; workers publish after commit. Consumers store processed-event keys. Design for at-least-once delivery and idempotent handling, not magical exactly-once network delivery.

Realtime payloads carry minimum data, resource version and event ID. Clients reconnect using cursor/last version and fetch canonical state. Authorize subscriptions to job/organization channels. Do not broadcast customer address or location on public provider channels.

## 4. State machines

Keep independent state dimensions. One giant status field cannot represent job, quote, custody and payment truth safely.

| Domain | Normal progression | Exceptions and guards |
| --- | --- | --- |
| Intake/request | draft → clarifying → customer_confirmed → searching → booked → closed | safety_hold, no_match, cancelled, expired; changed material facts require reconfirmation |
| Offer/response | sent → viewed → available/declined → selected/closed | expired; available creates bounded capacity hold |
| Job | booked → scheduled → en_route/awaiting_dropoff → arrived/received → diagnosing → awaiting_quote_approval → authorized → in_progress → ready/completion_pending → completed | cancelled, paused, failed, disputed; work requires approved scope |
| Quote | draft → submitted → approved/rejected/expired/superseded | Submitted versions immutable; approvals exact-version only |
| Custody | customer → courier/technician → shop → courier/customer | Every transfer acknowledged; loss/damage incident linked |
| Payment | pending → authorized → captured → partly_refunded/refunded | failed, cancelled, disputed; PSP events authoritative |
| Subscription | trial_if_enabled → active → past_due → restricted/cancelled | Grace/access policy explicit; records retained appropriately |

Drop-off skips en_route; home visit does not require shop custody. Cash payment uses an external-settlement record rather than a fictitious card capture. A support dispute overlays a job; it does not erase its earlier completion/financial history. Transition permissions and preconditions require an explicit table in code and tests. Manual overrides are audited and cannot bypass hard qualifications or silently charge a customer.

## 5. AI implementation and cost controls

### Candidate stack to benchmark

| Task | Initial candidate | Why it belongs / limit |
| --- | --- | --- |
| Speech-to-text | faster-whisper with multilingual Whisper small/medium; int8 on CPU where suitable | Practical self-hosted speech baseline; test accents/noise and actual server latency |
| Structured intake and routine translation | Qwen3-4B or Qwen3-8B through a private inference runtime | Candidate local multilingual model; validate structured outputs, negation and each launch language |
| RAG embeddings | Qwen3-Embedding-0.6B with PostgreSQL/pgvector if enabled | Compact retrieval candidate; pin dimensions and version, rebuild indexes when changed |
| Photo/model-label interpretation | Approved paid vision-capable Gemini/OpenAI endpoint initially | Use only needed images; validate brand/model and uncertainty; avoid CPU-heavy vision promises |
| Price range | PostgreSQL price rules + historical-data service | Exact arithmetic, evidence and localized ranges; no LLM invention |
| Text-to-speech, optional | Browser/platform voice initially | Availability/quality varies; always retain readable text |

Qwen and faster-whisper are candidates rather than claims of best/current-newest models. Review exact model/weight/runtime licences before shipping. Self-hosting cost includes hardware, power, monitoring and engineering. Existing CPU/RAM capacity can support a pilot benchmark but does not establish acceptable concurrent production latency. Isolate AI CPU/memory from the database and web workers. Start with bounded concurrency and measure.

The official faster-whisper repository documents CPU int8 execution; its benchmark is not a performance promise for this server [W1]. The Qwen3-8B and embedding cards are starting references for features/licences [W2–W3]. Do not deploy every available model at once.

### Routing policy

1. Check permission, input size and request budget; strip unnecessary personal information.
2. Run deterministic hazard/validation rules and retrieval where useful.
3. Use a benchmark-approved local model for routine extraction/translation.
4. Validate JSON and confidence signals; one bounded retry or clarification.
5. Escalate to an approved paid adapter only when permitted and within a budget.
6. Fail to editable text/manual support when no valid result is available. Booking/billing continue through deterministic forms where possible.

Set proposed per-intake caps: five clarification turns, two paid calls total, configurable input/output tokens and a €0.05 average variable-AI-cost pilot target per submitted request. This target excludes hardware, support, messaging and storage and is not a provider price. Long chat translation is separately measured and subject to fair-use limits. Daily organization/global budget caps, circuit breakers, per-IP/account throttles, duplicate request cache and maximum image/video duration prevent abuse.

Use a configurable paid-provider price registry rather than hardcoded “latest” prices. Cost formula: input_tokens/1,000,000 × input_rate + output_tokens/1,000,000 × output_rate + media/audio/tools costs; add FX when rates are USD and budgets EUR. Thinking tokens and media charges follow the selected endpoint's billing. Example with assumed rates $0.50 input/$2 output: 2,000 input + 500 output tokens = $0.002 for one call, excluding all other costs. This is arithmetic illustration, not a quoted tariff. Gemini's official rate page also distinguishes free/paid data-use conditions; select approved production terms for personal repair data [W4].

### Evaluation before enabling a model

Build an initial consented/synthetic 200-case test set across Italian/English/Bangla/Spanish, all categories, code-switching, noise, missing models, hazards and misleading/prompt-injection inputs. Include negation (“not leaking”), decimal amounts, dates and part numbers. Proposed pilot gates: schema-valid extraction ≥99%; critical numeric/quote field preservation 100% on the release fixture set; category accuracy ≥95% on labelled ordinary cases; no missed hard-rule hazard fixtures; every low-confidence case falls back safely. These are acceptance targets on the test set, not claims of real-world perfection. Human review of language quality is required. Record latency/cost percentiles and error slices by language, category and device. Re-evaluate before model/prompt changes.

## 6. Security, privacy and media

Use TLS, secure cookie/session handling, CSRF protection for cookie mutations, short-lived scoped mobile tokens, rate limits, OTP quotas and privileged MFA. Policies enforce organization and participant scope on every endpoint, export, background job and WebSocket channel. Use database row-level security as defense in depth where correctly integrated; application policy tests remain mandatory. Pooling/worker tenant context must be cleared between jobs.

Uploads use allowlisted MIME/extension signatures, byte/duration limits, malware screening, quarantined processing, EXIF/GPS stripping when appropriate, safe thumbnails/transcoding and private object storage. Proposed defaults: images up to 10MB each and ten per intake; video up to 60 seconds and 50MB; voice transcription up to two minutes. Limits are configurable and the user sees them before uploading. Finalize uploads server-side; do not trust a client-provided object key. Signed download URLs are short-lived and authorized per access.

Encrypt sensitive data/backups, keep secrets in a secret manager/environment, redact logs and restrict production access. Implement consent/notice versions, access/export/correction/deletion workflows, legal holds and data-category retention. Deletion propagates to derivatives, translations, search indexes and media, with accounting/legal exceptions documented. Customer identity and tenant contacts require a lawful-linking design; no phone-hash “anonymity” assumption. Choose processing regions and approved vendor contracts before real personal data is sent to cloud AI [W6].

AI output is escaped like any other user input; tool access is allowlisted and least privilege. No agent can issue a refund, edit a bank account or override a quote based solely on a conversation. PSP-hosted payment collection avoids storing raw card details.

## 7. Infrastructure and operational requirements

Deploy web/API, queue workers, scheduler, realtime service, AI worker, database, Redis and object storage explicitly. Uploading code alone is not deployment. Configure domains/TLS, secrets, mail/OTP, payment webhooks, maps/routing/geocoding, storage CORS, workers/supervisor/systemd, cron/scheduler, backups, monitoring and alert recipients. Produce `.env.example` without real credentials and a tested deployment/runbook.

Scheduled work includes offer/hold expiry, scheduled reminders, certification expiry, temporary-audio/media cleanup, retry/reconciliation, billing cycles, retention/deletion, notification retries and backup checks. Commands must be idempotent and avoid overlapping execution. Workers need timeout/retry/backoff/dead-letter rules; poison AI/media jobs must not block booking/payment queues.

Proposed initial targets to validate under a defined load: monthly core API availability 99.5%; ordinary non-AI API p95 below 500ms; user feedback within one second for asynchronous operations; local extraction p95 under ten seconds after upload, otherwise show progress/fallback. Pilot load profile: 100 concurrent authenticated users, ten new intake submissions/minute, and 50 simultaneous en-route sessions. Re-estimate from real demand. No fake benchmark claim.

Use point-in-time database recovery where supported, encrypted object versioning/backups and regular restore exercises. Proposed RPO 15 minutes and RTO four hours require actual infrastructure and a successful restore drill; do not promise them beforehand. Alert on outbox/queue lag, webhook failures, payment mismatch, offer expiry backlog, database saturation, AI latency/cost and storage errors. Keep trace IDs across a request without logging private raw content.

## 8. Development order and gates

Schedule is a planning range for a small experienced team, dependent on repository reuse, credentials, policy decisions and scope. A dependable web pilot may take roughly 12–18 weeks; it is not a delivery guarantee. Some design and operations work can overlap, but dependent integrity work must remain sequential.

| Step | Work and deliverable | Exit gate |
| --- | --- | --- |
| 0 — 1 week | Review this baseline; choose pilot area/categories, counterparty and fee trigger; audit existing source | Decision log and reuse matrix accepted |
| 1 — 1 week | Accessible mobile-first wireframes; test intake/quote with representative users | Owner approves representative flow before all screens |
| 2 — 1–2 weeks | Logical model review → physical schema, migrations, auth/tenant foundation, CI | Schema/invariants accepted; tenant isolation tests pass |
| 3 — 1–2 weeks | Catalog, onboarding and qualification review, availability | Ineligible workers cannot receive/perform restricted work |
| 4 — 1–2 weeks | Media, speech-to-text, confirmed intake, language preservation | Edited transcript survives; no unconfirmed dispatch |
| 5 — 1–2 weeks | Eligibility/scoring, offer rounds, holds and booking | Concurrency/expiry tests prove no duplicate booking |
| 6 — 1–2 weeks | Timeline, translated chat, appointments, foreground tracking | Reconnect and stale-location behavior work |
| 7 — 1–2 weeks | Quote revisions/approval, custody, completion | No unauthorized work; handover evidence survives failures |
| 8 — 1–2 weeks | PSP payments, platform billing, refunds/reconciliation | Sandbox webhook and concurrent first-fee tests pass |
| 9 — 1–2 weeks | Core shop CRM/manual jobs/calendar/reports and operations tools | Cross-workspace and manual-source billing tests pass |
| 10 — 1–2 weeks | Usability, load, accessibility, security, restore and operator drills | Launch checklist passes with real integrations |
| 11 — measured pilot | Controlled live area, human support, instrumented requests | Evidence supports expansion and native investment |

The summed sequence varies with reuse and overlaps; use gate-based planning rather than treating every estimate as a contractual date. Native apps follow a separate estimate after API/web acceptance. Advanced inventory and AI receptionist have their own milestones.

## 9. Codex working contract

Provide the Markdown package, decision register and actual repository. Ask Codex to read local `AGENTS.md`, inspect code and report current facts before editing. User authorization for this package does not authorize a later production deploy or emailing anyone. In the development session, give explicit scope and deployment authority separately.

For each feature, Codex must produce: requirement IDs covered, migration/API/UI changes, meaningful tests, changed paths, run commands, known gaps and a demonstration. Keep work in reviewable increments; use an isolated branch/worktree when the repository needs it. Do not erase existing migrations or user changes. A “done” feature must have real integration evidence or be clearly labelled mock/demo.

### First implementation prompt

“Read this requirements package and the repository instructions. Treat requirements v2 as the proposed baseline and flag conflicts. First produce a source/reuse audit and requirement traceability map; do not rewrite the application. After requirements approval, implement only Step 2 foundation with PostgreSQL/PostGIS migrations, organization-scoped authorization, CI and meaningful isolation tests. Preserve existing working code. Report actual commands/results and unresolved environment dependencies. Never claim a mocked integration is live.”

### Feature prompt template

“Implement [IDs] from [document], honoring approved decisions [IDs]. Inspect existing code and reuse it. Define schema/API/state effects first, then implement backend and UI, then test the stated failure/concurrency cases. Preserve tenant isolation, exact money and audit events. Use adapters for external services, include configuration documentation, and label unavailable credentials. Stop this increment when its exit gate passes; update traceability and the changelog.”

Use Codex for migration/API scaffolding, bounded feature implementation, fixture generation, review and regression fixes. Humans still approve ambiguous policy, user experience, real-language quality, business pricing and regulated launch. Do not ask an autonomous agent to infer legal eligibility from a free-text certificate or to “build everything perfectly” in one unreviewable change.

## 10. Mandatory test and release evidence

Test real database transactions for double acceptance, capacity races, unique relationship charging and webhook replay. Run against PostgreSQL/PostGIS rather than relying on SQLite for spatial/constraint behavior. Test two organizations and multiple staff roles for every private resource path, including AI retrieval, exports and sockets. Test revised quotes, out-of-order events, location expiry, DST scheduling, cash reconciliation and deleted contacts. Use mocked adapters for deterministic automated tests plus separate PSP/storage/OTP sandbox checks.

Every release needs CI results, dependency/security checks, restore evidence, accessibility/device checks, approved country configuration and a rollback plan. Deploy additive/backward-compatible changes first, backfill safely, then enforce constraints after validation. Rollback code without assuming an irreversible data migration can be undone. Production fixtures must never impersonate real bookings.
