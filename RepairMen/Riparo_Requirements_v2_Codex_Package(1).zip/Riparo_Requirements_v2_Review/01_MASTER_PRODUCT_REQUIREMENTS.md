# Riparo — master product requirements

Version 2.0 · Review baseline · 18 October 2026

## 1. Product purpose and scope

Riparo helps a person explain a repair problem in their own language, find a suitable verified professional, agree the scope and price, follow the work and keep the records. Professionals receive understandable requests, manage work and retain customer relationships. Shops manage marketplace and directly acquired customers in the same operational workspace.

The product must work for older people, migrants, people with limited literacy and users with little technical knowledge. Speaking, taking a photo and confirming a short summary must be enough to begin. Forms and maps remain available without becoming prerequisites for describing a problem.

### Product surfaces

| Surface | Users | Purpose | Release |
| --- | --- | --- | --- |
| Public website | Visitors, prospective providers | Explain services, trust, languages, pricing and coverage; acquire requests | Web launch |
| Customer web/PWA | Customers | Intake, selection, quote approval, job timeline, payment, history | Web launch |
| Professional web/PWA | Freelancers and shop staff | Offers, availability, work execution, translated chat | Web launch |
| Shop management web | Owner, manager, reception, dispatcher, accounts | CRM, calendar, jobs, team, quotes, invoices and reporting | Core at launch; advanced modules later |
| Operations console | Support, verifier, finance, platform admin | Verification, dispatch exceptions, disputes, billing and configuration | Web launch |
| Customer mobile app | Customers | Native access, camera, push, voice and job history | After web pilot |
| Technician mobile app | Working technicians | Native offers, push, navigation, active-job location and work log | After web pilot |

Full-product scope includes inventory, purchase/parts workflows, warranties, multi-branch operations and an inbound AI phone assistant. These remain specified but are phased; they must not block proving the core transaction.

## 2. Categories and service catalog

**CAT-01.** Use these stable category codes. Localized names can change without changing historical data.

| Code | English | Suggested Italian | Examples |
| --- | --- | --- | --- |
| electrical | Electrician | Elettricista | Sockets, switches, lighting, circuits; licensed scope only |
| gas | Gas systems | Gas | Gas appliances and installations; safety screening first |
| heating_cooling | Heating & AC | Riscaldamento e climatizzazione | AC, heat pumps, boilers, heating, refrigeration |
| mobile_tablet | Smartphone & tablet | Smartphone e tablet | Phones, tablets, supported wearable devices |
| computer_printer | Computer & printer | Computer e stampanti | Desktop, laptop, notebook, printer, monitor, networking |
| plumbing | Plumbing & bathroom | Idraulico e bagno | Leaks, taps, drains, toilets, showers, sanitary fixtures |
| home_appliances | Home appliances | Elettrodomestici | Washing machine, dishwasher, fridge, freezer, oven, dryer |
| other_unsure | Other / I'm not sure | Altro / Non lo so | AI-assisted categorization, reviewed before dispatch |

Home Appliances is retained because it is explicit in prior scope and covers frequent jobs omitted from the latest spoken category list. Refrigeration may be entered through Home Appliances, but qualification depends on the actual work: opening a refrigerant circuit differs from repairing an electronic control board. Heating may also involve gas; a category label alone never establishes legal eligibility.

**CAT-02.** Catalog hierarchy is category → subcategory → device/system type → optional brand → optional model. Brand is never a top-level trade. Examples: Computer → Laptop → Apple → MacBook; Appliances → Washing machine → Samsung → model.

**CAT-03.** A country/region/service-area matrix enables categories, modes, qualification requirements and schedules. Unsupported categories remain clearly marked unavailable, with a waitlist if enabled. “Other” routes to human triage when confidence is insufficient; it never bypasses trade checks.

**CAT-04.** Providers declare skills, work types, brands where relevant, exclusions, supported modes, travel area, hours, price basis and qualifications. A verified identity badge must not imply every trade is verified. Public badges explain precisely what was checked and when.

## 3. Roles, accounts and organizations

**ACC-01.** One human account can be a customer, an independent professional and a staff member, using an explicit workspace switch. Never mix permissions across workspaces. Customers may browse and draft a request before authentication; verify an account/contact before dispatch or payment.

**ACC-02.** A freelancer is a provider organization with one initial operator; a shop is a provider organization with staff and optional branches. The organization is the commercial counterparty, subscription owner and customer-acquisition fee owner. A worker is not a second billable shop solely because they receive an assignment.

**ACC-03.** Customer sign-in should begin with a simple OTP method; email/phone availability, anti-abuse cost and delivery determine the pilot choice. Support recovery, changing a verified contact, device/session revocation, account export and closure. Shop owners and privileged administrators require stronger authentication/MFA. Social sign-in is optional after the core flow works.

### Permission contract

| Role | Allowed scope | Restricted actions |
| --- | --- | --- |
| Customer | Own requests, conversations, approvals, payments, documents | Cannot access another customer's records |
| Freelancer owner | Own organization, jobs, CRM and billing | Cannot access another provider's records |
| Shop owner | All organization functions; delegate roles | Platform verification/ledger manipulation |
| Shop manager | Assigned branches and operational management | Owner-only billing/security changes unless delegated |
| Receptionist | Customer records, bookings, allowed communications | Restricted margin data, refunds, staff roles |
| Dispatcher | Offer response, assignments, availability, routing | Price/finance access only if explicitly granted |
| Technician | Assigned jobs, relevant contact details, notes, draft quotes | Unassigned private jobs and organization-wide finances |
| Accounts | Invoices, approved payment/refund actions, reports | Trade verification and unrelated private media |
| Platform support | Cases and minimum necessary request information | No silent impersonation or unrestricted finance changes |
| Verification reviewer | Evidence and category eligibility | No automatic payment authority |
| Platform finance | Subscriptions, ledger, refunds, reconciliation | No changing repair facts or certifications |
| Super administrator | Explicit controlled platform operations | All sensitive actions audited; no shared admin logins |

**ACC-04.** Staff invitations expire and grant only assigned branch/role access. Removing staff revokes sessions and job access; historical work authorship remains. Organization suspension stops new marketplace offers but must preserve lawful access to active job support and records under a defined policy.

## 4. Complete customer journey

**CUS-01 — Start.** Detect or ask display language; user can change it at any time. Ask city/postcode early to confirm serviceability without forcing exact GPS permission. Show one large “Tell us what needs fixing” action and all enabled categories. A category click preselects context but does not lock an incorrect diagnosis.

**CUS-02 — Explain.** Customer types or taps microphone, sees recording/transcription feedback, stops, edits the transcript and sends text. Photos and video are optional supporting evidence. Permission refusal must leave typing and file selection usable. Clearly show when recording is active. A failed recording offers retry or typed input without losing the rest of the draft.

**CUS-03 — Voice is text-first.** Temporary audio may be securely sent to a transcription service because browsers do not consistently offer suitable local recognition. It is not posted as a playable chat voice note by default. Transcript, original language, confidence and user corrections are the durable intake evidence. Proposed default deletes temporary audio within 24 hours of successful transcription; deployment retention policy must approve this value. Retaining audio for a separate evidence or call feature needs explicit purpose, notice and retention. Optional read-aloud is a separate accessibility action.

**CUS-04 — Organize.** AI produces a short user-language summary and structured fields: reported symptoms, category, device, brand/model if supported by evidence, urgency, possible hazards, required skills and missing questions. It distinguishes customer statements from inferred hypotheses. It must not invent a model, diagnosis or certification need from a low-quality photo.

**CUS-05 — Clarify.** Ask one question at a time, normally no more than 3–5 decision-relevant questions before offering human assistance or a technician diagnosis. Ask only missing details that change safety, eligibility, mode, timing or price confidence. Model number is optional when unknown; “I don't know” must be accepted. If the selected category conflicts with evidence, explain the proposed correction and ask confirmation.

**CUS-06 — Confirm ticket.** Show a plain-language summary, thumbnails, service mode, timing, area and optional non-binding estimate. Customer edits and confirms. AI may create a draft ticket automatically; dispatchable submission requires customer confirmation, verified contact, safety clearance and serviceability. Record the confirmed revision and language. A meaningful change after submission invalidates affected provider responses and triggers reconfirmation/rematching.

**CUS-07 — Choose mode.** Offer only supported modes: home visit, pickup–repair–return, or customer drop-off. Explain any call-out, diagnosis, pickup, delivery and storage charges before acceptance. Changing mode recalculates availability and price disclosures.

**CUS-08 — Timing.** Offer now/today/scheduled, subject to actual coverage. Earlier urgent 15-minute and normal 30-minute matching windows are proposed search windows, not guaranteed technician arrival times. Scheduled work needs explicit start/end, timezone and provider capacity reservation. The customer can change time before booking; afterwards use rescheduling rules and mutual confirmation.

**CUS-09 — Search and select.** Explain that suitable providers are being contacted. Show responses as they arrive, normally no more than three at once. Each card shows organization/person, verified work scope, review count, languages, service mode, arrival/appointment estimate, price basis and response expiry. Customer may select one, decline, adjust preferences, wait for more or cancel. When a provider responds, request a permitted chime plus a visible banner and accessible announcement. The system cannot guarantee audible ringing when a browser/app is backgrounded, muted or restricted.

**CUS-10 — Confirm booking.** Choosing a provider atomically reserves one job and closes competing responses. Show any agreed diagnosis/call-out charge and cancellation policy before final confirmation. A second click/retry must not create another job. Customer can access translated chat and call options after booking; public offer cards do not expose the precise home address or phone number.

**CUS-11 — Follow work.** One job timeline combines provider confirmation, appointment, en route/ETA, arrival identity, diagnosis, quote, work, ready/return, completion, payment and support. Show last update time; stale location is labelled. The customer sees organization and assigned technician, and is notified when assignment changes.

**CUS-12 — Approve quote.** A diagnosis may lead to an itemized, versioned quote. Show labour, parts, diagnosis, travel, pickup/return, disposal, discount and applicable taxes separately. State which charges are already paid or credited. Customer explicitly approves a specific quote version and amount. If rejected, stop repair work and apply only previously agreed diagnosis/return charges. An increased scope requires a new version and approval; a chat message or AI response cannot substitute for the approval action.

**CUS-13 — Complete and pay.** Technician submits work summary and useful completion evidence. Customer confirms or reports an issue. A disputed completion cannot silently become an approved charge merely because a timer expired; any proposed timed process must be disclosed and reviewed. Online card or supported country-specific methods use a payment provider. Cash/external payment is recorded as such with a receipt where supported and a clear dispute policy. Payment failure does not erase job evidence.

**CUS-14 — Aftercare.** Keep approved quotes, invoice/receipt, warranty information, payment state and job history. Permit verified-job review, support/dispute and rebooking the same organization. The product must distinguish technician warranty promises, statutory rights and any platform guarantee. Do not advertise a guarantee that has not been funded and legally defined.

## 5. Professional journey and requirements

**PRO-01 — Onboard.** Choose freelancer or shop, create business profile, contact, service area, skills, hours, languages, modes and payout details. Submit identity/business/qualification evidence appropriate to location and work type. AI can extract fields; a reviewer or approved authoritative verification process decides eligibility. Rejected or expired evidence explains what needs correcting and provides appeal/support.

**PRO-02 — Presence and availability.** Provider can go online, offline, busy or scheduled-only. Presence heartbeats expire; an open browser alone is not proof of readiness. Job capacity, actual schedule, leave, branches and travel time control eligibility. Part-time providers are eligible during their declared hours without a blanket ranking penalty. Going offline stops new immediate offers while preserving active jobs.

**PRO-03 — Receive an offer.** Show translated symptoms, category, approximate area, mode, required skills, requested time, media permitted for the offer stage, estimate disclaimer, disclosed first-customer fee and response deadline. Hide precise address and sensitive customer details until booking. A provider can accept availability, suggest a time, decline with a reason, or report mismatch. Accepting availability is not an approved repair quote.

**PRO-04 — Shop response.** A permitted dispatcher may respond for a shop only if there is qualifying capacity. Final assignment requires a qualified staff member. A gas/heating job cannot be assigned to an unqualified employee merely because the shop has another qualified worker, unless the specific jurisdiction/supervision policy permits that work arrangement.

**PRO-05 — Before arrival.** Confirm appointment, route, disclose delay, communicate through translated text and optionally voice/video calling. Mark en route to enable limited active-job location sharing. Navigation can open a mapping app. Exact location sharing ends when the journey/job stage ends or is cancelled.

**PRO-06 — At work.** Arrival identity check, diagnosis, notes, photos, parts list, draft quote, customer approval, work log, checklists, labour time, extra-work request, completion and warranty. A customer-held arrival code is shown/said to the arriving technician and validated by the technician in the system; successful validation confirms the booked job. Rate-limit attempts; allow a support fallback when a customer cannot use the code. It is not an emergency authentication barrier.

**PRO-07 — Money and history.** Clearly separate repair earnings, customer balances, provider processing charges, platform subscriptions and one-time acquisition fees. Show gross revenue, refunds, recorded cost and contribution with definitions. “Profit” is not asserted if costs, taxes or staff labour are missing.

**PRO-08 — Repeat customers.** Rebooking remains with the organization. A customer may choose a preferred employee if available. No new acquisition fee for employee/branch reassignment within that organization. Changing legal ownership or splitting/merging organizations requires audited relationship migration and explicit fee treatment.

## 6. Matching and dispatch

**MAT-01 — Hard eligibility first.** Filter active country/area/category/mode, verified scope and valid qualifications, suspension/block rules, availability/capacity, travel feasibility, appointment compatibility and customer/provider safety exclusions. Mandatory constraints cannot be bought, waived by an LLM or overridden through ranking.

**MAT-02 — Proposed organic scoring.** Score normalized values on 0–1 using the following initial weights, versioned and configurable by area/category. This is a hypothesis to validate, not a trained optimal algorithm.

| Factor | Weight | Definition |
| --- | --- | --- |
| Relevant skill and device fit | 25 | Verified scope and demonstrated relevant work |
| Travel/arrival feasibility | 20 | Mode-specific ETA or route feasibility, not distance alone |
| Reliability | 15 | On-time arrival, completed commitments, upheld cancellations |
| Quality | 15 | Verified-job ratings with sample-size smoothing |
| Current responsiveness | 10 | Recent valid response behavior during declared availability |
| Shared language preference | 5 | User-chosen communication preference; translation remains available |
| Fair opportunity | 10 | Exposure opportunity among eligible, ready providers |

Score = sum(weight × normalized factor). For each scoring version specify normalization, evidence window, missing-data defaults and ties. New providers start with neutral reliability/quality priors; they must not be permanently buried for having no reviews. Proposed prior: quality = (10 × area-category baseline + sum of verified ratings)/(10 + rating count), normalized to 0–1. Baseline defaults to neutral when local evidence is absent. Freeze scoring inputs per dispatch round for reproducibility.

**MAT-03.** Do not use nationality, ethnicity or culture as matching or price variables. Shared language is optional and user-controlled; do not infer nationality from language. Do not penalize a professional simply for being part-time. “Always online” earns no direct reward without honest availability and response quality.

**MAT-04 — Commercial influence.** The requested “who pays more” factor is handled as a separate future sponsored-placement module, clearly labelled and subject to eligibility, distance and quality floors. Baseline €9 subscribers use the organic matcher. No hidden pay-to-win weighting; no sponsored launch until pricing, disclosure and country review are approved.

**MAT-05 — Dispatch rounds.** Proposed urgent starting parameters: contact up to five suitable provider organizations, require a response within 90 seconds, retain availability responses for five minutes and display the best three. Expand search at configured intervals until the 15-minute search window ends. Normal jobs may search up to 30 minutes; scheduled jobs use explicit response deadlines rather than repeated ringing. These values are configuration defaults for review and may vary with geography. One shop receives one offer even if multiple employees qualify.

**MAT-06 — Atomic booking.** Provider response reserves capacity temporarily under an expiring hold. Customer booking rechecks eligibility, response expiry and capacity in a transaction. Use a database guard for one active booking per request and lock the relevant capacity reservation. If two customers select the same worker/time, only a valid available slot may commit. Other offers close only after the booking commits. Expiry, decline, cancellation and disconnection release holds idempotently.

**MAT-07 — Fairness and recovery.** Reserve a proposed 10% exploration share across eligible new/underexposed providers, still meeting qualification and ETA floors. Cap simultaneous offers, prevent repeated spam to a declining professional, log exposure and reasons, and monitor by area/category and declared availability. Lack of work is not enough to outweigh customer suitability. If no response, offer expansion of time/radius, a different mode or human assistance; never invent an available technician.

**MAT-08 — Explainability.** Store eligible candidate set, exclusion reasons, scoring inputs/version, round, ranking, response outcome and assignment result with restricted access. Public explanations use simple relevant reasons without leaking private data. A human dispatcher can intervene with a recorded reason while respecting hard constraints.

## 7. Communication and translation

**COM-01.** Preserve original submitted text and source language. Generate translations per target language and source revision. Display translated text, a translation indicator and a “View original” action. Corrections invalidate old translations. Original text is never silently overwritten by a polished summary.

**COM-02.** Preserve numbers, currencies, addresses, brand/model identifiers, part numbers, dates and quote line items. A structured approval/price object is authoritative; translated prose is explanatory. Uncertain critical translation prompts reconfirmation or a human interpreter/support route.

**COM-03.** Launch languages proposed: Italian, English and Bangla, with Spanish prepared for the US pilot. Architecture supports BCP-47 language tags and RTL. Do not promise every language has passed QA; unsupported/low-confidence speech offers typing, another supported language or assistance. Customer and provider independently choose UI language.

**COM-04.** Text chat, media, delivery/read status, reporting and appointment events are core. Voice input in chat also becomes editable text before send. Optional calls are separately scoped: ordinary audio call first; live speech translation and video later. Call recording is disabled by default; country-appropriate notice/consent and retention are prerequisites for enabling it.

**COM-05.** Before booking, questions should use a mediated, limited offer Q&A with no exact address/contact disclosure. After booking, participants and authorized shop staff can communicate. Blocking/reporting stops abusive messages without destroying job records or the support path.

## 8. AI behavior, RAG and pricing estimates

**AI-01.** Use a provider-neutral AI gateway. Separate transcription, extraction, translation, retrieval, vision and user-facing phrasing. Each job records model/version, prompt version, input revision, tokens or processing duration, latency, validation result and cost estimate. Do not store unnecessary personal prompt content in analytics.

**AI-02.** A structured intake response must conform to a versioned JSON schema. It includes reported facts, hypotheses, evidence links, confidence, missing fields and next question. Reject invalid results, allow one bounded repair/retry, then fall back to simpler UI or human triage. The AI cannot execute arbitrary tools, SQL or administrator actions.

**AI-03.** Treat uploaded documents, OCR and RAG text as untrusted evidence. Instructions embedded in a photo/manual/message cannot change safety rules, billing, permissions or tool access. Retrieve only from approved, rights-cleared sources and tenant-scoped internal records. Never index one shop's CRM into another shop's search context.

**AI-04.** RAG stores source, permissions, locale, equipment scope, version, effective dates, confidence and retrieval citations. Start with approved troubleshooting summaries, manufacturer/service information permitted for use, qualification policies and local price data. If evidence is missing, say so. RAG is retrieval, not an internet scraping licence and not proof of diagnosis.

**AI-05 — Price engine.** LLM identifies plausible work and required questions; deterministic pricing code computes ranges from local historical jobs and curated price rules. Inputs include country/city, currency, equipment/work type, labour, diagnostic/call-out, travel, parts ranges, urgency, mode and tax policy. Return low/high, inclusions/exclusions, confidence, sample size, source freshness and expiry. A wide or absent range is better than invented precision.

**AI-06.** Example only: a supported local dataset might return €30–€50 for a defined minor job. This must not be presented as a default for all repairs. If parts/model/inspection are unknown, explain that the technician will diagnose and quote. US estimates need state/local rules and USD price data, not an EUR-to-USD conversion of Italian labour rates.

**AI-07.** No inference of guaranteed fault, technician qualification, payment completion or emergency safety. The actual quote comes from the provider; the customer approves. AI estimates do not authorize work, create binding price commitments or charge money.

**AI-08.** Local low-cost models handle suitable routine tasks after benchmarking; paid Gemini/OpenAI adapters handle approved escalation/vision when local results fail quality or latency gates. No assumption that self-hosted is free or that every request should call multiple paid models. See the technical plan for candidates, budget rules and a test set.

## 9. Service mode operations

**OPS-01 — Home visit.** Capture access instructions privately: floor, lift, doorbell, accessibility, parking where relevant. Notify assignment and arrival changes; provide identity/code checks, quote approval and support. A location permission refusal permits a typed address and map confirmation.

**OPS-02 — Pickup/return.** Create pickup and return appointments, named custody holders, item identifier, serial if available, accessories, condition photos, acknowledgement, transport responsibility and status at each transfer. A customer sees where the item is and who holds it. Failed pickup, inaccessible address, damaged/lost item, declined quote and return-only costs have explicit workflows and support escalation. A completed bench repair is not final delivery.

**OPS-03 — Drop-off.** Show shop address, opening hours and confirmed appointment/instructions. Generate a receipt or handover reference with item/accessories/condition. Track received → diagnosis → quote → repair → ready → collected. Collection uses a secure handover method and a delegate authorization path. Uncollected items use a reviewed notification/storage policy, never automatic disposal from an AI decision.

**OPS-04 — Device privacy.** Do not request device PINs/passwords in public descriptions or standard chat. If access is necessary, use a reviewed secure, time-limited process or customer-present unlock; minimize stored secrets. Photos can contain private screens/addresses: warn simply, restrict access and allow replacement/redaction where practical.

## 10. Shop management system

**SHOP-01 — CRM.** Customer list, verified/entered contact, communication language, consent/preferences, addresses, devices, history, notes, warranty and open balances. Distinguish marketplace-acquired customers from shop-owned/walk-in contacts. A local CRM contact does not automatically become a platform account or receive marketing messages.

**SHOP-02 — Manual jobs.** Reception can create a phone/walk-in job, link an existing contact, identify a device and use the same quote/work/payment timeline. Manual shop acquisition has no marketplace acquisition fee. If a customer account is later linked, require verified authority/consent and preserve provenance.

**SHOP-03 — Calendar/dispatch.** Day/week schedule, worker skills/hours, assignment, absence, travel buffers, multi-worker visits, appointment change notifications and collision prevention. The organization remains accountable for customer communication. Large jobs can have multiple staff but one provider counterparty and quote owner.

**SHOP-04 — Quotes/documents.** Draft, send, revision history, approval, conversion to job, deposits where supported, invoice/credit note/receipt, export and warranty. Store business/legal/tax identity snapshots with issued documents. Issued invoices cannot be silently edited; corrections use appropriate document processes.

**SHOP-05 — Inventory, deferred.** Parts catalog, supplier, SKU/part number, quantity by branch/location, reserved parts, purchase/receipt, consumption against job, returns and stock adjustments. Prevent overselling reserved parts. Keep movement history rather than only editing a balance. Reorder alerts follow configured minimum stock. Integrations and supplier automation come after a reliable internal ledger.

**SHOP-06 — Financial view.** Collected/outstanding repair revenue, refunds, parts cost, recorded labour, platform fees and margin. Reports are organization/branch scoped and currency-specific. Export for the accountant. Tax filing, payroll and audited accounts are separate integrations, not implied by showing a dashboard.

**SHOP-07 — Multi-branch and plans.** Core model supports branches and staff; the first interface may focus on one branch. Proposed €9 Core includes essential marketplace, CRM, scheduling, quotes and document history with published fair-use limits. Advanced inventory, telephony and additional capacity can become optional plans only after founder approval. Do not invent compulsory per-seat charges.

**SHOP-08 — AI phone receptionist, deferred.** Identify business and AI clearly; collect caller language/problem/contact, check availability, draft or confirm an appointment within delegated rules, send confirmation and hand off to staff. It must not promise unsafe service, approve quotes, invent capacity or charge money. Recording, telephony costs, interruption, emergency handling, spam and failed-call recovery need their own acceptance suite. AI minutes are metered and cannot be unlimited inside €9 without demonstrated economics.

## 11. Revenue, billing and payments

**BILL-01 — Subscription.** Founder requirement: €9/month for a freelancer/provider organization or direct shop organization. Proposed per organization, not per staff member. Store plan, effective price, currency, tax treatment, seats/branches/features and fair-use limits as versioned configuration. EUR is the approved baseline; US subscription pricing is a separate review decision. The application must disclose whether €9 is tax-inclusive before selling it.

**BILL-02 — One-time acquisition.** Founder requirement: €1–€4 once for each first marketplace customer–provider organization relationship. Proposed exact launch fee €2; not yet approved. Proposed charging trigger is the first completed marketplace job, after completion eligibility is established. This avoids charging several technicians who merely responded. Fee disclosure occurs before response/booking; the backend stores the actual policy version and amount. The founder may choose booking-time billing after reviewing cancellation/refund consequences.

**BILL-03 — Relationship rules.** Relationship key is customer identity + provider organization. First job with shop A → one acquisition fee for A; repeat at A or another A employee/branch → zero further acquisition fee; first completed job with independent B → one fee for B. Direct/walk-in imports → no acquisition fee. Multiple devices, addresses, categories and employees do not create a new relationship. Account recovery and verified merges preserve history.

**BILL-04 — Concurrency and refund.** Two first jobs finishing together must create one relationship and at most one charge. Separate a durable relationship record from append-only charge attempts and adjustments. Refunds create credit entries. A refunded acquisition fee does not silently delete the relationship or cause it to be charged again; exceptional reversal/re-eligibility needs an audited policy. Deleted accounts must not become a simple fee-avoidance mechanism; preserve only the minimal legally approved billing linkage, with disclosed retention.

**BILL-05 — Collection.** Prefer aggregate monthly invoicing of acquisition fees with the subscription to avoid card-processing overhead on €1 transactions. Record each qualifying event individually; aggregate only collection. If invoice payment fails, retry according to disclosed rules, notify owner and use a grace period. Do not hold customer repair funds or active safety communication hostage to a failed subscription.

**BILL-06 — Repair payment.** The customer's repair bill is separate from Riparo subscription/acquisition revenue. Use a marketplace-capable payment provider and verified provider onboarding where Riparo routes payments. Define merchant/counterparty, refunds, disputes, payout timing and fee bearer before launch. No platform repair percentage is included in the founder's baseline model. Processor/FX/dispute fees still exist and must be allocated transparently. Do not build an unlicensed internal escrow wallet.

**BILL-07 — Monetary integrity.** All stored amounts have currency and exact minor-unit/decimal representation; never floating-point money. Historical quotes, taxes and invoices use snapshots. Payment webhooks are authenticated, deduplicated, order-independent and reconciled. A browser success page is not proof of payment. Refunds cannot exceed captured refundable balances.

## 12. Platform operations, safety and disputes

**SAFE-01.** A deterministic multilingual hazard screen runs before and during intake and when new evidence changes risk. Potential gas leak, fire, live shock risk and dangerous flooding interrupt ordinary booking. Show locally approved guidance and the appropriate official emergency route. Do not imply a repair technician substitutes for emergency responders, or that tapping acknowledgement proves the property is safe. Resume normal repair handling only through the approved incident policy.

**SAFE-02.** The console supports verifier queues, evidence expiry alerts, abuse reports, reassignment, no-show, cancellations, incident cases and disputes. Each action has actor, reason, timestamp, affected revision and audit event. Support access is purpose-limited and logged; exports and high-impact finance actions need extra control.

**SAFE-03.** Verified reviews come from actual completed jobs; allow a provider response and moderation/appeal. Prevent repeated self-review, review purchase and threats. Review removal follows a recorded policy rather than payment level. Handle customer and provider no-shows with documented evidence and previously disclosed fees.

**SAFE-04.** Dispute records contain issue, evidence, deadlines, communications, decision and financial adjustments. Customer sees a clear support path for damage, disputed price, missing item, unsafe conduct or poor repair. Refund, warranty return and rework are separate outcomes. Rework for the same relationship never triggers a new acquisition fee.

## 13. Global configuration and accessibility

**LOC-01.** Store country, region/state, city/service zone, postal code, timezone, language and currency explicitly. Country activation is an operational switch, not inferred from IP. Customer may change location; IP is only a suggestion. Addresses accept local formats. Store UTC instants plus scheduling timezone; display dates/times locally and handle daylight-saving transitions.

**LOC-02.** Support localized content and fallbacks, RTL layout, decimal/number formatting, kilometer/mile display and tax presentation. A request, quote, job and invoice retain the relevant country/currency snapshots. Do not sum mixed currencies into one earnings number without an explicit FX view and dated conversion rate.

**LOC-03.** Target WCAG 2.2 AA for web, with keyboard/screen-reader testing, visible focus, text alternatives, contrast and dynamic text. Use at least 48px practical touch targets, plain-language labels, text alongside icons, clear error recovery and no color-only status. An elderly person must complete intake without navigating a dense dashboard. Voice input, read-aloud and assisted service are options, not mandatory steps.

**LOC-04.** Browser restrictions must be visible in the plan: background location and ringing are limited on PWA. Native technician app is required for reliable supported background tracking after permissions/platform review. Web pilot promises foreground tracking and explicit status updates with fallback notifications, not continuous Uber-grade background operation on every phone.

## 14. Release boundaries and acceptance

### Release A — managed Italian web pilot

One selected service area with approved providers and real operational support. All eight catalog entries are modeled; only staffed and approved work scopes are bookable. Core PWA journeys, transcription-to-text, translated text, hard-filter matching, customer selection, quote approval, three mode data models, home/drop-off operations, controlled pickup if staffed, payments, basic shop CRM/calendar/documents, billing and operations console. If pickup custody is not proven, show it unavailable rather than simulating it.

### Release B — dependable web operation

Improve matching from evidence, automate reconciliation, introduce inventory/multi-branch features, deepen quote/tax-document integrations, extend language QA and add operational regions. Real scheduled work, exception handling and customer support must pass before expansion.

### Release C — native mobile

Separate customer and technician apps, same API/business rules, native push/camera/voice, approved active-job background location and device-specific accessibility. No second independent billing implementation in the apps.

### Release D — approved international expansion

Additional European markets and one selected US market after category licensing, tax, invoice, payment, insurance, consumer/privacy, emergency and support reviews. “Global architecture” is not evidence that every market can legally or operationally launch immediately.

### Release E — AI phone and advanced services

Inbound AI receptionist, optional advanced plans, approved live speech translation, supplier integrations and measured sponsored placement. Enable only with adequate margins, consent and operational controls.

The requirement register and acceptance scenarios accompany this document. Core launch gates are: no cross-shop data access; no duplicate booking or acquisition fee; approved quote required; qualification enforced; translation preserves transactional facts; real payment reconciliation; no fake coverage; tested recovery from AI, queue, media and notification failure.
