# Provisional logical database blueprint

This document precedes physical schema approval. It describes what the database must represent and protect. It is not executable SQL or a verified migration set. Existing 104-table/other schemas must be compared against these rules before reuse; table count is not a quality target.

## 1. Universal conventions

- PostgreSQL is the durable system of record; PostGIS provides geography and spatial querying.
- UUID primary keys; UUIDv7 may be generated in application code with a documented compatible fallback. Pin actual engine/extension versions before choosing database-specific defaults.
- Use UTC `timestamptz` for instants, plus IANA timezone and local schedule intent where needed. Recurring hours are local rules, not fixed UTC offsets.
- Monetary fields have currency and integer minor units or exact numeric with explicit scale. Quantities/rates use exact numeric; totals use currency rounding rules. Never use float for money.
- Tenant-owned records carry `organization_id`; participant-shared marketplace records have explicit ownership/access joins. Composite foreign keys or equivalent enforced guards prevent cross-tenant joins.
- Record creator, timestamps and row version on mutable aggregates. Submitted quotes, issued documents and ledger events are immutable records with adjustment/revision processes.
- Soft deletion is a workflow option, not a privacy deletion strategy. Retention, erasure and legal holds are separate explicit processes.
- Use enums/checks for stable internal states and catalog tables for changeable business lists. JSONB holds raw model evidence or flexible metadata, not a substitute for required searchable financial/relationship fields.

## 2. Entities and principal fields

Fields below are minimum conceptual content. All entities have an ID and appropriate created/updated metadata unless expressly immutable. Physical types, naming and indexes are finalized after review.

| Group | Entities and essential data | Relationships / constraints |
| --- | --- | --- |
| Global config | countries, subdivisions, currencies, languages, service_zones, category_market_rules | Zone has country/timezone/geometry; enable each work scope/mode explicitly |
| Identity | users, verified_contacts, auth_identities, sessions, consent_records | Unique normalized verified contact according to recovery policy; consent version/purpose |
| Provider | organizations(type freelancer/shop), branches, memberships, roles, role_permissions, membership_scopes | Membership unique user+organization; branch belongs to same organization |
| Customer | customer_profiles, customer_addresses, customer_devices | Platform customer identity independent of shop-local CRM contact |
| Catalog | categories, subcategories, work_types, brands, models, model_aliases, work_qualification_rules | Stable codes; catalog links support cross-category equipment safely |
| Provider capabilities | provider_services, worker_skills, provider_languages, service_areas, business_hours, absences | Distinguish organization eligibility from assigned worker scope |
| Verification | verification_cases, evidence_files, certifications, certification_scopes, verification_decisions | Subject organization/person, jurisdiction, issuer, validity, checked_at and reviewer |
| Availability | presence_sessions, availability_slots, capacity_holds, capacity_reservations | Heartbeat expiry; booking window and worker/organization capacity |
| Intake | intakes, intake_revisions, transcription_runs, extracted_facts, clarification_turns | Preserve original text, corrected transcript, source language and confirmed revision |
| Media | media_assets, media_attachments, processing_jobs | Owner/purpose/storage key/hash/MIME/bytes/status/retention; no public storage ACL |
| Requests | service_requests, request_items, request_locations, request_time_windows, safety_assessments | Request source, category/work scope, mode, country/currency, confirmed revision |
| Estimates | price_rules, local_price_observations, estimate_runs, estimate_components | Price source/version/sample/confidence/tax scope; do not overwrite old estimates |
| Dispatch | dispatch_rounds, match_candidates, provider_offers, provider_responses | Offer per round+organization; scoring version, reasons and expiry |
| Jobs | bookings, jobs, job_assignments, job_events, appointment_changes | Single active booking per request; revisions and actor-authorized transitions |
| Custody | custody_items, handover_events, custody_acknowledgements, transport_legs | Item condition/accessories/from/to/location/time/evidence and current holder projection |
| Quote | quotes, quote_versions, quote_lines, quote_approvals | Approval references immutable version/hash and customer; all amounts/currency snapshot |
| Work | diagnoses, work_logs, job_parts, completion_reports, customer_confirmations | Assigned actor, permitted state and quote scope |
| Communication | conversations, conversation_participants, messages, message_revisions, message_translations | Original language/text retained; translation unique revision+target language+version |
| Location | location_samples, active_tracking_sessions | Worker+job, en-route state, sampled_at/received_at/accuracy/sequence; short retention |
| Notifications | notification_preferences, notifications, delivery_attempts, device_tokens | Event+recipient+channel dedup key; never confuse delivered with read |
| Repair funds | payment_orders, payment_attempts, captures, refunds, disputes, payout_references, webhook_receipts | Provider external IDs unique; exact amount/currency, append-only financial events |
| Platform billing | plans, plan_versions, subscriptions, billing_periods, provider_customer_relationships, acquisition_events, billing_ledger_entries, platform_invoices | Relationship key customer+provider organization; price/policy version at event time |
| Shop CRM | shop_contacts, shop_contact_links, contact_notes, contact_devices, contact_consents | Tenant-local identity; verified link to platform customer optional and controlled |
| Shop operations | manual_job_sources, branch_schedules, supplier_contacts, inventory_items, stock_locations, stock_movements, part_reservations, purchase_orders, purchase_lines | Manual jobs use shared job engine; stock movement ledger and tenant-safe suppliers |
| Documents | document_sequences, issued_documents, document_lines, credit_notes, warranty_terms, warranty_cases | Issuer/country/series/period uniqueness; immutable snapshots and corrections |
| Trust/support | reviews, review_responses, reports, support_cases, incident_events, moderation_actions | Verified job constraint; case-limited evidence access |
| AI/RAG | ai_runs, model_configs, prompt_versions, knowledge_sources, knowledge_documents, knowledge_chunks, embeddings, retrieval_runs, ai_feedback | Access scope, source rights/version, model/dimension, costs and input revision |
| Reliability/privacy | outbox_events, consumed_events, idempotency_records, audit_events, privacy_requests, retention_policies, legal_holds | Transactional outbox; request hash conflict guard; append-only audit with controlled retention |

This inventory covers the full intended product; deferred entities do not all need migrations in the first release. Partition volatile location/AI/event history only when evidence justifies it. Keep the first physical design as small as the approved release permits.

## 3. Critical relationship examples

One user has many memberships; one organization has many branches and members. One organization owns each shop contact and stock item. A platform customer can have many unrelated shop-local contact records without granting cross-shop visibility.

One intake has many immutable revisions. One service request points to its confirmed revision, mode, location and schedule. It can have many dispatch rounds and provider offers, but at most one active booking. One job belongs to the booked provider organization and has many staff assignments/events. Reassignment changes the worker, not the commercial provider or acquisition relationship.

One job has quote headers and multiple versions; an approval points to one submitted version. Work logs reference the approved scope/version where relevant. A revised quote does not delete the earlier approval. A repair invoice and a platform invoice have different issuers and economic purposes even when linked to the same job.

One relationship connects a verified platform customer identity to one provider organization. It records first marketplace acquisition provenance and current fee disposition. Many jobs can reference it; only one qualifying acquisition charge is allowed under the current policy.

## 4. Non-negotiable integrity rules

| Invariant | Proposed database/application enforcement |
| --- | --- |
| One active booking per request | Unique partial index on request for active booking states; transaction and explicit lifecycle |
| One response per provider/offer | Unique provider offer/response key and command idempotency |
| No worker double booking | Explicit time ranges; exclusion constraint for single-capacity workers, transaction/slot locking for multi-capacity organizations |
| One customer acquisition per provider organization | Unique canonical customer+organization relationship; unique charge purpose+relationship key; transactionally record ledger/outbox |
| No quote approval drift | Approval FK to immutable version; amount/currency/hash snapshot; command checks expected revision |
| No job starts without approval | Transition service verifies valid quote/scope approval or explicitly approved pre-priced task; audit and tests |
| No cross-organization children | Composite IDs/FKs or validated scoped associations for branch/member/contact/job/stock relationships |
| No double webhook effect | Unique external provider+event ID; durable receipt before processing; monotonic/allowed financial transitions |
| No mutable issued financial evidence | Append-only issued rows, credit/adjustment entries; restricted write roles |
| No mixed-currency arithmetic | Currency compatibility checks at quote/job/payment/document boundaries |
| No confidential media leakage | Ownership/participant purpose checks before signing object access; quarantine until processing complete |
| No duplicate mutation on retry | Idempotency record unique actor/workspace+route+key, stored request hash and response |

Do not rely solely on Redis locks. Locks can expire during processing; unique constraints and transactional state guards remain authoritative. Idempotency keys reused with different request bodies must reject instead of returning unrelated prior success.

## 5. Booking transaction

1. Resolve authenticated customer and load submitted request, selected response and relevant capacity row with locking.
2. Recheck ownership, confirmed revision, response expiry, qualification validity, mode and timing.
3. Convert an available hold into a durable reservation and insert active booking/job; database constraint rejects duplicate active booking.
4. Record selected organization/worker, initial price disclosures and policy version. Do not charge the later repair quote here.
5. Append job event and outbox notification in the same transaction; commit.
6. Close competing offers and release holds through idempotent events. On race failure return a clear refresh/reselect state.

If an offer promised only organization capacity, assignment must still resolve qualifying worker capacity before the appointment can be committed or before the disclosed assignment deadline. Do not allow indefinite overbooking hidden behind “shop accepted.”

## 6. Acquisition fee transaction

1. Accept one authorized `JobCompleted` eligibility event; source must be marketplace and policy must qualify the event.
2. Resolve canonical customer identity and booked provider organization; create/upsert the unique relationship.
3. Lock relationship; if already charged/exempt under policy, record no-charge reason and stop.
4. Insert acquisition event and ledger debit with immutable fee/tax/currency/policy snapshots and a unique relationship purpose key.
5. Mark fee disposition, append outbox record and commit. Monthly collection can aggregate these debits separately.
6. Credits/refunds append ledger adjustments; retain prior event and relationship. Replay has no second financial effect.

Contact merge must redirect both jobs and relationships through a reviewed canonicalization service. If merging accounts reveals duplicate historical fees, create an auditable adjustment rather than deleting ledger rows. Provider mergers/splits and customer account erasure require separate policies before implementation.

## 7. Geography and search design

Store service location and worker position as appropriate PostGIS geography/geometry with SRID consistency. Use spatial indexes and meter-based `ST_DWithin` candidate filtering where suitable, then route/ETA estimation for the shortlisted candidates. A straight-line distance is not a promised road arrival time. Model service areas as polygons and/or radius rules with explicit mode support. Drop-off ranks by shop accessibility/distance and opening times; pickup considers both legs.

Sensitive home coordinates are private. Public nearby-provider maps show approximate locations or areas; never leak precise worker/customer positions to anonymous users. Live samples include accuracy, time and current job scope. Discard stale/out-of-order points for display while retaining necessary audit under the approved policy.

## 8. Index, retention and migration plan

Prioritize indexes on tenant+status/time, request/booking state, offer expiry, worker/time overlap, relationship customer+organization, provider external event ID, quote version and conversation+sequence. Add GiST for spatial/time exclusions where applicable. Inspect query plans with representative data; do not index every column speculatively.

Proposed retention classes: temporary transcription audio ≤24 hours after successful transcription; short-lived unconfirmed drafts with a configured expiry; location samples short-lived after the job; financial documents per reviewed jurisdiction policy; support evidence per case/legal hold. Exact periods besides the audio proposal remain decisions. Privacy deletion must include object derivatives, AI logs, search chunks and caches, with documented billing/legal retention exceptions.

After requirement approval: audit old schema → map old tables to domains → identify conflicts → write migration ADRs → implement additive migrations and seed catalogs → test fresh install and supported upgrade → generate ERDs and data dictionary → test backup/restore. Never silently run old SQL plus new migrations with overlapping incompatible definitions. Physical schema deliverable must include actual PK/FK/check/index definitions, ownership, retention and example queries, with migration tests on the chosen engine.
