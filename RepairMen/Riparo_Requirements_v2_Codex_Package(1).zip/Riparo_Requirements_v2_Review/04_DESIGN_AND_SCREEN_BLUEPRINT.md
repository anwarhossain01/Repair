# Artistic design and screen blueprint

This is the design contract for the next design stage. It is not a claim that every final screen has been drawn. Approve requirements and three representative flow screens before producing the full customer, professional and desktop screen sets.

## 1. Direction from the supplied work

The reviewed `Repair App Wireframes(1).pdf`, page 1, uses a hand-drawn wordmark, outlined conversation cards, restrained accents, simple phone frames, a ticket inside the thread and a compact map after matching. Its second alternative is map-first. Preserve the illustrated, human character and functional clarity. Adapt the old voice-message depiction to the new requirement: microphone input becomes editable text before sending. Do not copy old fee or emergency behavior without the updated product rules.

The earlier design handoff specifies warm paper `#FAF7F2`, ink `#201D1A`, trust green `#2C7A62` and terracotta `#C4622D`, Bricolage Grotesque headings, Instrument Sans body and Bangla fallback. These are retained starting tokens. Verify contrast in actual component states; not every colored text/background combination is suitable for small text.

Use artistic line illustrations of tools, appliances and friendly service moments, with restrained paper-like shapes. Avoid photographic category tiles, glossy device renders, rainbow category grids and decorative gradients. Keep letterforms readable; use the hand-drawn treatment for wordmark/illustrations rather than critical long text. Artwork never substitutes for a button label or error explanation.

## 2. Experience structure

**Customer:** category/voice-first entry followed by a guided conversation. A clear ticket card, provider-response cards, quote card and job timeline live within or beside that conversation. The map appears when it helps explain travel; it does not dominate the first experience or expose precise locations before booking.

**Professional:** action-first home: availability switch, next appointment and incoming requests. Use larger cards with “Available”, “Suggest time” and “Decline”. Separate work execution from earnings/billing to avoid accidental financial actions.

**Shop desktop:** calm workspace with Customers, Jobs, Calendar, Team, Quotes/Documents, Payments, Inventory when enabled, Reports and Settings. A job detail page is the common spine for customer, device, timeline, staff, quote, custody and communication. Avoid a dense chart dashboard before basic tasks are easy.

**Operations:** queues and exception details, with explicit status, reason and audit trail. Show exactly why a qualification, match, payment or upload is blocked.

## 3. Layout and interaction tokens

Design at 390px mobile and verify 320px width, 200% text zoom and large system text. Desktop layouts cover common 1280–1440px workspaces. Use an 8px spacing rhythm, generous whitespace, 16–24px card radius, thin ink/neutral outlines and little or no shadow. Practical touch targets ≥48px, body text around 16–18px, primary action around 18px where fitting. Long translated labels may wrap; never truncate the meaning of Approve/Pay/Cancel.

Customer bottom navigation proposed: Home, Repairs, Messages, Profile; one prominent “New repair” action is always reachable. Earlier five-item navigation can be tested, but avoid two competing new-repair controls on a small screen. Professional navigation: Today, Requests, Jobs, Messages, More. Web desktop uses persistent side navigation and clear workspace switch.

Critical action hierarchy: one filled primary action, a clear secondary action, and a separate destructive action requiring context. Buttons say what happens: “Confirm ticket”, “Choose this professional”, “Approve €84.00 quote”, “Pay €84.00”. A repair estimate must not appear as the price on a pay button.

## 4. Representative screen compositions

### A. Customer home

Top: illustrated Riparo wordmark, editable service area, language control. Main: “What needs fixing?” with a simple line illustration and large “Tell us” microphone/text action. Then the eight named categories with readable labels and consistent line icons; “I'm not sure” remains obvious. Bottom: current job or last professional when relevant. No login wall before explanation.

### B. Intake and ticket confirmation

One short AI prompt; original text bubble; editable voice transcript preview; camera/video controls. A confirmation card shows equipment/problem, mode, time/area and “Estimate unavailable” or an evidenced range. Always show “Edit” and “Confirm ticket”. Errors preserve entered text. The review screen labels uncertain model detection instead of implying certainty.

### C. Professional responses

Visible “A professional is available” banner, permitted chime and up to three comparable cards. Card: organization, assigned/expected professional, relevant verification, rating/count, languages, time and disclosed call-out/diagnosis basis. Primary “Choose” action; expiry is understandable. Show no-match recovery when needed. Sponsored placement, if ever enabled, has its own label.

### D. Job, quote and payment

Timeline shows next action; active map is compact and last-updated. Translated chat exposes original text. Quote includes itemized total and separate approve/reject actions. Work-started state follows approval. Completion and payment distinguish provider confirmation, customer acceptance and PSP pending/success. Documents and support remain visible after completion.

## 5. Customer screen inventory

| IDs | Screens | Required variants |
| --- | --- | --- |
| C01–C04 | Welcome/language; service area; home/categories; category detail | Unsupported area/category, returning customer |
| C05–C09 | Intake text; voice transcript review; photo/video upload; clarification; safety interruption | Permission denied, upload/transcription failed, uncertain language/model |
| C10–C14 | Ticket review/edit; OTP/account; mode selection; timing; address/access | Unknown model, no GPS, unavailable mode, timezone conflict |
| C15–C19 | Searching; responses; provider profile; booking confirmation; no-match recovery | Expired response, lost capacity, cancellation |
| C20–C24 | Job timeline; map/ETA; translated chat; call handoff; arrival check | Stale location, translation unavailable, changed technician |
| C25–C29 | Diagnosis; quote detail; quote approval; revised quote; waiting/work state | Reject, expire, extra work, previously paid diagnosis credit |
| C30–C34 | Pickup/drop-off handover; custody detail; ready/return; completion review; issue report | Missing accessory, failed delivery, damaged/lost item |
| C35–C39 | Payment choice; PSP handoff; payment result; documents/warranty; review | Failed/pending/refunded payment, disputed completion |
| C40–C44 | Repair history; rebook; profile/preferences; privacy/account; support case | Closed provider, account recovery, export/deletion pending |

These are reusable screen/state families, not 44 compulsory separate pages in code. Shared flows may use drawers/cards where usability permits. Every screen needs loading, empty, validation, offline/retry and permission-aware behavior where relevant.

## 6. Professional and shop screen inventory

| IDs | Screens / families | Notes |
| --- | --- | --- |
| P01–P05 | Type selection, business/identity, skills/modes, languages/area/hours, evidence upload/review | Document expiry/reject/resubmit |
| P06–P10 | Today/availability, request list, request detail, response/time proposal, booking result | Expired offer and lost-slot states |
| P11–P15 | Calendar, assignment, route/en-route, arrival validation, diagnosis/work checklist | Role/skill and location permissions |
| P16–P20 | Quote builder, submitted quote, approved work log, parts/photos, completion | Revised quote blocks extra work |
| P21–P25 | Custody handover, ready/return, translated chat/call, customer history, warranty/rework | Item/accessory evidence |
| P26–P30 | Earnings/balance, platform subscription, acquisition-fee ledger, notifications, profile/support | Repair funds separated from platform charges |
| S01–S05 | Shop overview, CRM list/detail, manual booking, device history | No marketplace fee for own acquisition |
| S06–S10 | Dispatch board, team/roles, branch settings, calendar capacity, job detail | Multi-staff with one organization |
| S11–S15 | Quotes/documents, payments/refunds, revenue/cost reports, export, settings/billing | Correct permissions and currencies |
| S16–S20 | Inventory, suppliers/purchases, stock movements, warranty queue, AI receptionist settings | Later phase unless specifically enabled |

## 7. Public web and operations inventory

Public pages W01–W12: home, service directory, category detail, approved area page, how it works, trust/safety, language support, professional recruitment, provider pricing, FAQ, contact/support and legal/privacy/terms. Additional account/request pages reuse the customer PWA. Public provider profile may be enabled only with consent and a defined publication policy. Index only real service areas and useful localized content; private tickets/chat/media stay out of search indexing.

Operations O01–O12: overview/alerts, verification queue/detail, provider/organization detail, request/match trace, job/incident detail, support/dispute, subscription/acquisition ledger, payment reconciliation, catalog/territories, policy/model configuration, audit/privacy requests and reporting. Permissions govern every view and action.

## 8. Prototype validation and handoff

First build Home → Intake → Ticket → Responses → Quote → Completion for one ordinary job; include transcript failure, no match and quote change. Test with 5–8 representative users including older, migrant and less technically confident people. Proposed task goal: most participants can submit a correct request and explain the approved price without assistance. Record actual findings, not a fabricated pass rate.

After review, deliver high-fidelity mobile customer/pro screens, responsive desktop shop/operations screens, reusable components/tokens, localized long-text examples, redlines, interaction notes and keyboard/screen-reader behavior. Native app screens follow the same approved journey, with documented platform push/location/camera differences. Final visual design is a separate deliverable after this requirements review, as requested.
