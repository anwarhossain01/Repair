# Riparo — investor and partner brief

Review-stage product case · Not a fundraising valuation or verified financial forecast

## 1. Customer problem and proposition

When something breaks, many customers cannot describe the technical fault, judge the right trade or communicate comfortably in the local language. Repair businesses receive fragmented calls and messages, spend time clarifying requests and often manage quotes, parts and customer history in disconnected tools.

Riparo proposes one simple journey: explain the problem in your language, confirm an understandable ticket, choose an eligible professional, approve the price and follow the job. Shops keep the relationship and manage repeat work in their own workspace. This is a product hypothesis based on the founder's brief; customer demand and willingness to pay still need live pilot evidence.

## 2. Three priority value hypotheses

| Workflow | Change | Expected benefit | Measurement / evidence posture |
| --- | --- | --- | --- |
| Describe and triage | Voice-to-text, photos, structured clarification | Less abandonment and fewer unsuitable dispatches | Completion rate, clarification time, mismatch rate; assumed until measured |
| Coordinate and authorize | Translated conversation, timeline, exact quote approval | Fewer misunderstandings and price disputes | Response/arrival time, quote approval rate, upheld disputes; assumed |
| Operate and retain | CRM, schedule, documents and no repeat acquisition charge | More organized repeat work and provider retention | Repeat usage, monthly churn, support minutes; assumed |

Differentiation must be demonstrated in this combined workflow. Do not claim Riparo is the first, only or best AI repair marketplace, or that a model by itself guarantees superior matching.

## 3. Product and launch strategy

The full product has customer access, professional access, shop management and operations. A responsive web/PWA pilot establishes the transaction and supply quality before separate native apps. Proposed first operational market: one staffed Italian service area with approximately 15–25 approved provider organizations as a recruitment target. The final city/zone is not newly confirmed; earlier work recommended a Rome-area pilot. Expand to other approved European areas and a selected US city/state after operational and jurisdiction readiness.

The architecture supports multiple languages, currencies, regions and timezones. This is a global expansion design, not proof of immediate worldwide coverage. Early gas/electrical hazardous incidents route to approved emergency handling rather than an ordinary repair booking.

## 4. Founder-defined revenue model

Known from latest brief: €9 monthly per freelancer/provider organization or shop organization; €1–€4 once per new marketplace customer–organization relationship; repeat jobs with that organization have no new acquisition fee. Proposed exact fee €2 and first-completed-job trigger await review. The fee is paid by the provider, not by every technician receiving an offer. Repair bill value is separate from platform revenue.

Advanced inventory, higher capacity, telephony/AI minutes or clearly labelled sponsorship may create optional later revenue. These are unapproved extensions and excluded from the baseline below. There is no hidden repair commission in this model. US plan prices, tax inclusivity and processor-fee allocation remain open.

## 5. Illustrative monthly revenue scenarios

Formula: paying provider organizations × €9 + qualifying first-customer relationships × effective acquisition fee. Count a relationship once, not every ticket, employee or repeat repair. Values below are assumptions for sensitivity, not demand forecasts or existing traction. Use revenue excluding indirect taxes; if the advertised €9 includes tax, recognized net revenue is lower.

| Scenario | Providers | New pairs / month | Fee | Plan revenue | New-pair fees | Total before costs |
| --- | --- | --- | --- | --- | --- | --- |
| Small pilot | 100 | 200 | €1 | €900 | €200 | €1,100 |
| Working local network | 500 | 1,500 | €2 | €4,500 | €3,000 | €7,500 |
| Broader rollout | 2,000 | 8,000 | €4 | €18,000 | €32,000 | €50,000 |

At the working-network assumption, acquisition revenue would be €1,500/€3,000/€6,000 at a €1/€2/€4 fee, producing €6,000/€7,500/€10,500 total with 500 subscriptions. The outer scenarios deliberately change both scale and fee; they are not comparable growth forecasts.

Repair GMV is the value of customer repairs and is not Riparo revenue. Customer funds owed to providers are not available operating profit. Refunds, discounts, failed collections and churn reduce realized revenue. Annualizing an illustrative month does not establish ARR for variable acquisition income.

## 6. Cost and sustainability

Main costs: engineering, support/dispatch, provider verification, acquisition/marketing, servers, AI, translation, media, notifications/OTP, maps, payment/FX/disputes, insurance/legal/accounting and charge/refund losses. No verified cost baseline or acquisition/churn evidence was supplied, so profit and break-even provider counts cannot be credibly promised.

At a pure planning assumption of €0.05 variable AI cost per submitted request, 10,000 requests consume €500 in variable AI; this excludes messaging, infrastructure and human handling. A six-minute support interaction at an assumed €15/hour costs €1.50, which can consume much of a €1–€2 acquisition fee. This is why support workload and fair use matter as much as token savings.

For a provider with an assumed three new charged relationships/month at €2 each: gross platform revenue = €9 + 3×€2 = €15/month before taxes, losses and costs. Contribution per provider = net recognized subscription + net acquisition revenue − allocated variable AI/messaging/verification/support/payment costs. Break-even providers = fixed monthly costs / positive average contribution per provider. Missing inputs: actual fixed costs, net plan price, variable workload, collection losses, CAC and churn.

Low price helps recruitment but leaves little room for unlimited live AI calls, media or manual support. Preserve the €9 baseline while publishing reasonable capacity/fair-use limits and offering optional metered costly features only after validation. Self-hosting needs measured total cost and latency, not a claim of free AI.

## 7. Pilot proof and investment decisions

Proposed evidence collection: first 100 qualified service requests, actual matched/accepted/completed jobs, two monthly subscription renewal cycles, and interviews with retained and departed providers. These are targets, not achievements. Track channel, request category/language, serviceability, response/selection, ETA adherence, price accuracy, refund/dispute, support minutes, total variable cost and repeat relationships.

Define qualified request consistently: customer-confirmed, serviceable, non-duplicate, verified contact, within enabled scope, and not an emergency referral. Define paying provider as collected subscription rather than merely registered. Retention uses cohorts; reviews and completion rates need denominators and sample counts.

Proposed expansion gates: reliable eligible supply during advertised hours; at least 70% of qualified pilot requests booked; at least 80% of booked jobs completed without unresolved operational failure; no unresolved critical safety/data/payment defect; positive measured variable contribution or an approved route to it. Small pilot samples cannot prove rare safety events are solved. These thresholds are initial management targets requiring review, not market benchmarks.

Funding should follow evidence gates: validate and recruit → implement trustworthy web transactions → run controlled live pilot → improve retention/contribution → invest in native apps and new markets. Budget and funding amount remain missing and should be built from the team's actual costs after repository audit. No valuation or investment return is asserted.

## 8. Partner roles and open evidence

Local repair partners supply qualified capacity, transparent prices, custody discipline and aftercare. Community/language partners can help usability and recruitment with consent-based outreach. Payment, insurance and document providers can close jurisdiction-specific operational gaps. The founder/team supplies the platform, onboarding, support and honest reporting.

Known: product brief, proposed pricing and earlier demos/source foundations. Inferred: the integrated workflow may reduce friction. Assumed: willingness to pay, conversion, retention and cost targets. Missing: audited deployment readiness, signed provider supply, market-specific activation approvals and real cohort economics. A credible partner presentation should show the product as proposed/demo until those facts are established.
